window.ue_adb_chk = 1;
